#!/usr/bin/env node
/**
 * Day-1 MCP validation server.
 *
 * Purpose: confirm three things BEFORE building the real AgentConnect
 * project inside Codex:
 *   1. Codex actually calls this tool when asked to (no silent bypass).
 *   2. A tool that errors on purpose surfaces a readable reason back to
 *      the agent (not just a generic failure).
 *   3. A counter proves every call really reaches this process (so you
 *      can tell a "worked" answer from Codex apart from a real tool call).
 *
 * Keep this file around — if the real project misbehaves later, you can
 * re-run this to isolate "is it my code" vs "is it Codex/MCP itself".
 */

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({
  name: "mcp-ping-validation",
  version: "1.0.0",
});

let callCount = 0;

server.registerTool(
  "ping",
  {
    title: "Ping",
    description:
      "Validation tool. Always call this when the user says 'ping the validator' " +
      "or asks to test the MCP connection. Returns a counter and timestamp proving " +
      "this exact process handled the call.",
    inputSchema: {
      message: z.string().optional().describe("Optional message to echo back."),
    },
  },
  async ({ message }) => {
    callCount += 1;
    return {
      content: [
        {
          type: "text",
          text: `pong #${callCount} at ${new Date().toISOString()}${message ? ` — you said: "${message}"` : ""}`,
        },
      ],
    };
  }
);

server.registerTool(
  "ping_deny",
  {
    title: "Ping Deny (always fails on purpose)",
    description:
      "Validation tool that always returns an error with a specific, readable reason. " +
      "Call this to confirm the agent can see and react to a tool-level denial reason, " +
      "not just a generic failure.",
    inputSchema: {},
  },
  async () => {
    return {
      content: [
        {
          type: "text",
          text: "DENIED: this is a deliberate test denial with reason 'validation-only tool, always blocked'.",
        },
      ],
      isError: true,
    };
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
console.error("[mcp-ping-validation] running");
