# Day-1 MCP Validation — ChatGPT Desktop App (No Terminal Needed)

Goal: confirm Codex reliably calls a local MCP tool and surfaces error
reasons back to you, BEFORE spending 4 days building the real project on
top of this assumption.

## 1. Get the files onto your machine

Unzip `mcp-ping-validation.zip` somewhere permanent, e.g.:

```
~/projects/mcp-ping-validation/
```

Then install its one dependency. You need a terminal for this **one** step
only (npm install has no UI equivalent):

```bash
cd ~/projects/mcp-ping-validation
npm install
```

Note the **full absolute path** to `server.mjs` inside that folder — you'll
need to paste it in step 4. On macOS it looks like
`/Users/yourname/projects/mcp-ping-validation/server.mjs`.

## 2. Open ChatGPT desktop app

Make sure you're on the merged app (Chat / Work / Codex in one window, not
"ChatGPT Classic"). If you see three modes in the sidebar, you have the
right one.

## 3. Open MCP settings

- Click your profile icon or the gear icon → **Settings**
- Find **MCP servers** in the settings list
- Click **Add server**

## 4. Fill in the server

- **Name:** `ping-validator`
- **Transport:** select **STDIO**
- **Command:** `node`
- **Arguments:** the absolute path to `server.mjs` from step 1
  (e.g. `/Users/yourname/projects/mcp-ping-validation/server.mjs`)
- Click **Save**, then click **Restart** when it appears

## 5. Confirm it's connected

- Switch to the **Codex** mode/tab
- In the composer, type `/mcp`
- You should see `ping-validator` listed as connected, with two tools:
  `ping` and `ping_deny`

If it's NOT listed here, stop — something is wrong with the local setup
(wrong path, node not found, etc.) and you need to fix this before testing
anything else. Common fix: use the full path to `node` too
(run `which node` in a terminal once to get it) instead of just `node`.

## 6. Run the actual test

In a Codex conversation, type exactly:

```
Use the ping-validator tool to ping with the message "test 1".
```

**What you're checking:**
- Does Codex actually call the tool (you should see a tool-call indicator
  in the UI), or does it just guess/answer in text without calling anything?
- Does the response include `pong #1 at <timestamp>`? The number proves the
  real process was hit — if you ask again it should say `#2`, not `#1` again
  (that would mean it's not really calling the tool, or a new process spins
  up per call, either of which changes your project's design assumptions).

Then type:

```
Use the ping-validator tool to call ping_deny.
```

**What you're checking:**
- Does Codex show you the denial reason ("validation-only tool, always
  blocked") in a way that's readable, or does it just show a generic
  "tool failed" message with no detail?
- This is the exact behavior your AgentConnect project depends on: when a
  destructive query gets denied, the *reason* has to reach you/the agent
  clearly, not get swallowed.

## 7. Decision point

- ✅ **Both checks pass** → MCP is stable and predictable enough on your
  setup. Proceed with the AgentConnect build as planned.
- ⚠️ **Tool gets called but reasons are vague/generic** → still proceed,
  but make error messages in the real project extra explicit in the
  `content` text itself (don't rely on `isError` alone), since that's the
  only part that reliably surfaces.
- 🛑 **Codex doesn't reliably call the tool at all** → this is the pivot
  signal from Risk #1. Come back and we'll adjust the project shape
  (e.g., leaning more on hook-based Bash interception instead of MCP, or
  simplifying scope) before you lose more build days to it.
